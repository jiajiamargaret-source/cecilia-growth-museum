CECILIA GROWTH MUSEUM — STRUCTURE DEMO

This version shows the full museum structure:
Innovation Lab, Maker Workshop, Art Studio, Explorer, Storytelling.

Upload photos into folders and rename:
01.jpg, 02.jpg, 03.jpg...

Important folders:
images/art/birds/
images/art/animals/
images/art/aurora/
images/art/houses/
images/art/watercolor/
images/art/holiday-cards/

images/innovation/future-of-trash/
images/innovation/earth-guardian-boat/

Later we can duplicate gallery-template.html for each collection.
